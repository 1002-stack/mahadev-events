MAHADEV EVENTS - PREMIUM WEBSITE

Business: Mahadev Events
Phone/WhatsApp: 6356348424
Instagram: mahadev_events_001
Location: Bharuch

Features:
- Luxury wedding/event design
- Responsive mobile layout
- Animated scroll reveals and hover effects
- Sticky navigation
- Real uploaded photos
- Book Now enquiry form
- Form sends enquiry details directly to WhatsApp

Open index.html to preview. Upload all files together to your web host.
